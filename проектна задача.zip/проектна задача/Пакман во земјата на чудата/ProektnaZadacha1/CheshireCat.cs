﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using ProektnaZadacha1.Properties;

namespace ProektnaZadacha1
{
    public class CheshireCat
    {
        Image Machka;
        Color Color;
        int[][] nasoki;

        public CheshireCat(int h, int w)
        {
            Machka = Resources.chesircat;
            nasoki = new int[h][];
            for (int i = 0; i < h; i++)
            {
                nasoki[i] = new int[w];
                for (int j = 0; j < w; j++)
                {
                        nasoki[i][j] = 1;
                }
            }
        }

        public void Draw(Graphics g, int i, int j)
        {
            g.DrawImageUnscaled(Machka, j * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - Machka.Height) / 2, i * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - Machka.Width) / 2);
        }

        public void Move(bool [][]cats, int h, int w)
        {
            for(int i = 0; i < h; i++)
            {
                for(int j = 0; j < w; j++)
                {
                    if (cats[i][j] == true && j == w - 1)
                    {
                        nasoki[i][j] = -nasoki[i][j];
                    }
                    if (cats[i][j]==true && j == 1)
                    {
                        nasoki[i][j] = -nasoki[i][j];
                    }
                    if(cats[i][j]==true)
                    {
                        cats[i][j] = false;
                        nasoki[i][j + nasoki[i][j]] = nasoki[i][j];
                        cats[i][j + nasoki[i][j]] = true;
                    }
                }
            }
        }
    }
}
