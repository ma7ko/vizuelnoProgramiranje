﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProektnaZadacha1.Properties;

namespace ProektnaZadacha1
{
    public partial class Form1 : Form
    {
        Pacman pacman;
        public readonly static int widthw = 15;
        public readonly static int heightw = 10;
        Timer timer;
        Image goodFood;
        Image badFood;
        Image house;
        Image Bottle;
        bool[][] goodFoodMap;
        bool[][] badFoodMap;
        bool[][] cheshireCats;
        bool[][] wasApple;
        int goodfoodsno = 5;
        bool postignataCel;
        bool imaVeshterka;
        bool isColided;
        int hasBottle;
        int Xbot;
        int Ybot;
        int shansa = 0;
        int zhivot = 3;
        Veshterka w;
        CheshireCat cat;
        public Form1()
        {
            InitializeComponent();
            goodFood = Resources.apple1;
            badFood = Resources.candy;
            house = Resources.house1;
            Bottle = Resources.bottle;
            DoubleBuffered = true;
            imaVeshterka = false;
            isColided = false;
            hasBottle = 0;
            initializeMatrix();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.White);
            for (int i = 0; i < heightw; i++)
            {
                for (int j = 0; j < widthw; j++)
                {
                    if (goodFoodMap[i][j])
                    {
                        g.DrawImageUnscaled(goodFood, j * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - goodFood.Height) / 2, i * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - goodFood.Width) / 2);
                    }
                    if (badFoodMap[i][j])
                    {
                        g.DrawImageUnscaled(badFood, j * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - badFood.Height) / 2, i * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - badFood.Width) / 2);
                    }
                    if(cheshireCats[i][j] && pacman.isAlice)
                    {
                        cat.Draw(g, i, j); 
                    }
                }
            }
            g.DrawImageUnscaled(house, Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - house.Height) / 2, Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - house.Width) / 2);
            pacman.Draw(g);
            if (imaVeshterka)
            {
                w.Draw(g);
            }
            if (hasBottle==1)
            {
                g.DrawImageUnscaled(Bottle, Ybot * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - Bottle.Height) / 2, Xbot * Pacman.initialRadius * 2 + (Pacman.initialRadius * 2 - Bottle.Width) / 2);

            }
        }

        private void initializeMatrix()
        {
            postignataCel = false;
            goodfoodsno = 5;
            shansa = 0;
            pacman = new Pacman();
            w = new Veshterka(new Point(7, 5));
            cat = new CheshireCat(heightw,widthw);
            this.Width = Pacman.initialRadius * 2 * (widthw + 1);
            this.Height = Pacman.initialRadius * 2 * (heightw + 1) + 50;

            goodFoodMap = new bool[heightw][];
            badFoodMap = new bool[heightw][];
            cheshireCats = new bool[heightw][];
            for(int i = 0; i < heightw; i++)
            {
                goodFoodMap[i] = new bool[widthw];
                badFoodMap[i] = new bool[widthw];
                cheshireCats[i] = new bool[widthw];
                for(int j = 0; j < widthw; j++)
                {
                    goodFoodMap[i][j] = false;
                    badFoodMap[i][j] = false;
                    cheshireCats[i][j] = false;
                }
            }

            int randombroj = 0;
            int vlegov = 0;
            Random random = new Random();
            for (int i = 0; i < heightw; i++)
            {
                int brojr = random.Next(5, heightw-1);
                for (int j = 0; j < widthw; j++)
                {
                    int brojk = random.Next(2, widthw);
                    if (randombroj < 5)
                    {
                        if (vlegov == 10)
                        {
                            Xbot = brojr;
                            Ybot = brojk;
                            vlegov++;
                            break;
                        }
                        else if (goodFoodMap[brojr][brojk] == false && badFoodMap[brojr][brojk] == false && cheshireCats[brojr][brojk]==false)
                        {
                            goodFoodMap[brojr][brojk] = true;
                            vlegov++;
                            randombroj++;
                        }
                    }
                    else
                    {
                        if (vlegov == 10)
                        {
                            Xbot = brojr;
                            Ybot = brojk;
                            vlegov++;
                            break;
                        }
                        else if (randombroj < 10)
                        {
                            if (badFoodMap[brojr][brojk] == false && goodFoodMap[brojr][brojk] == false && cheshireCats[brojr][brojk] == false)
                            {
                                badFoodMap[brojr][brojk] = true;
                                vlegov++;
                                randombroj++;
                            }
                        }
                    }
                }
                if (vlegov == 11)
                    break;
            }
            zhivot = 3;
            int catkol = 13;
            int catkol1 = 13;
            cheshireCats[6][catkol] = true;
            cheshireCats[8][catkol1] = true;
            toolStripStatusLabel1.Text = "Број јаболки: " + goodfoodsno.ToString();
            toolStripStatusLabel4.Text = "Животи: " + zhivot;
            timer = new Timer();
            timer.Interval = 250;
            timer.Tick += new EventHandler(timer1_Tick);
            timer.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
            int calculatedXPos = Math.Abs(pacman.Xpos / 40);
            int calculatedYpos = Math.Abs(pacman.Ypos / 38);

            //so it wont go out of bounds
            if (calculatedXPos == widthw)
            {
                calculatedXPos--;
            }
            if (calculatedYpos == heightw)
            {
                calculatedYpos--;
            }

            //check if there is food on the coords and eat it
            if (goodFoodMap[calculatedYpos][calculatedXPos])
            {
                goodFoodMap[calculatedYpos][calculatedXPos] = false;
                goodfoodsno--;
                toolStripStatusLabel1.Text = "Број јаболки: " + goodfoodsno.ToString();
                pacman.DecreaseRadius();
            }
            if (badFoodMap[calculatedYpos][calculatedXPos])
            {
                badFoodMap[calculatedYpos][calculatedXPos] = false;
                pacman.IncreaseRadius();
                imaVeshterka = true;
            }
            if (pacman.Radius >= 10 && !pacman.isAlice)
                toolStripStatusLabel2.Text = "Пакман е премногу голем";
            else
            {
                toolStripStatusLabel2.Text = "";
            }
            if (cheshireCats[calculatedYpos][calculatedXPos] && pacman.isAlice)
            {
                if (shansa == 3)
                {
                    if (zhivot == 0)
                    {
                        gameOverCats();
                        return;
                    }
                }
                Random r = new Random();
                int red = r.Next(2, heightw);
                int kol = r.Next(5, widthw);
                goodFoodMap[red][kol] = true;
                postignataCel = false;
                goodfoodsno++;
                shansa++;
                odzemiZhivot();
                toolStripStatusLabel1.Text = "Број јаболки: " + goodfoodsno.ToString();


            }
            if (hasBottle>0 && calculatedXPos==Ybot && calculatedYpos==Xbot)
            {
                pacman.isAlice = true;
                hasBottle = 2;
            }
            if (goodfoodsno==0 && (pacman.Radius<10 || pacman.isAlice))
            {
                postignataCel = true;
            }
            if (goodfoodsno==0 && pacman.Radius>=10 && hasBottle==0)
            {
                secondChance();
            }
            if(isInHouse() && postignataCel)
            {
                win();
            }
            if (imaVeshterka)
            {
                pacman.Move();
                w.Move();
                isColided = w.isColiding(pacman.Xpos, pacman.Ypos);
                if(isColided)
                {
                    gameOverWitch();
                }
                if (pacman.isAlice)
                {
                    cat.Move(cheshireCats, heightw, widthw);
                }
            }
            else
            {
                pacman.Move();

            }

            Invalidate(true);
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    if (pacman.Direction != Pacman.DIRECTION.up)
                    {
                        pacman.ChangeDirection(Pacman.DIRECTION.up);
                    }
                    break;
                case Keys.Down:
                    if (pacman.Direction != Pacman.DIRECTION.down)
                    {
                        pacman.ChangeDirection(Pacman.DIRECTION.down);
                    }
                    break;
                case Keys.Left:
                    if (pacman.Direction != Pacman.DIRECTION.left)
                    {
                        pacman.ChangeDirection(Pacman.DIRECTION.left);
                    }
                    break;
                case Keys.Right:
                    if (pacman.Direction != Pacman.DIRECTION.right)
                    {
                        pacman.ChangeDirection(Pacman.DIRECTION.right);
                    }
                    break;
                default:
                    break;
            }

            Invalidate();
        }

        private void win()
        {
            timer.Stop();
            MessageBox.Show("Победивте");
        }

        private void gameOverWitch()
        {
            timer.Stop();
            toolStripStatusLabel4.Text = "Животи: 0";
            if(MessageBox.Show("Дали сакате нова игра?","За жал, ве фати вештерката, изгубивте.", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                initializeMatrix();
                timer.Start();
                imaVeshterka = false;
            }
            else
            {
                Application.Exit();
            }
        }

        private void gameOverCats()
        {
            timer.Stop();
            if (MessageBox.Show("Дали сакате нова игра?", "За жал немате повеќе животи, ве фатија мачките, изгубивте", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                initializeMatrix();
                timer.Start();
                imaVeshterka = false;
                hasBottle = 0;
            }
            else
            {
                Application.Exit();
            }
        }

        private bool isInHouse()
        {
            if (pacman.Xpos < 120 && pacman.Xpos>20 && pacman.Ypos>5 && pacman.Ypos < 80)
                return true;
            return false;
        }

        private void secondChance()
        {
            timer.Stop();
            MessageBox.Show("Браво, ги собравте сите јаболки, но се уште сте големи. Со помош на шишенцето претворете се во Алиса и влезете дома!");
            hasBottle = 1;
            timer.Start();
        }

        private void odzemiZhivot()
        {
            zhivot--;
            toolStripStatusLabel4.Text = "Животи: " + zhivot;
        }
    }
}
